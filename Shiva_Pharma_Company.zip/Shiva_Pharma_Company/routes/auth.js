const express = require('express');
const router = express.Router();
const svgCaptcha = require('svg-captcha');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const pool = require('../db');

// Ensure users table exists
async function ensureTable(){
  const create = `
    CREATE TABLE IF NOT EXISTS users (
      email VARCHAR(255) PRIMARY KEY,
      full_name VARCHAR(255) NOT NULL,
      phone VARCHAR(30) NOT NULL,
      shop_name VARCHAR(255) NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `;
  const conn = await pool.getConnection();
  try{ await conn.query(create); } finally { conn.release(); }
}
ensureTable().catch(console.error);

// captcha
router.get('/captcha', (req, res) => {
  const captcha = svgCaptcha.create({ size:4, noise:2, ignoreChars: '0oO1ilI', color: true });
  req.session.captcha = captcha.text;
  res.type('svg');
  res.status(200).send(captcha.data);
});

// register
router.post('/register', async (req, res) => {
  try{
    const { full_name, email, phone, shop_name, password, captcha } = req.body;
    if(!full_name || !email || !phone || !shop_name || !password || !captcha){
      return res.status(400).json({ message: 'Fill All Fields' });
    }
    if(!req.session.captcha || captcha.toLowerCase() !== req.session.captcha.toLowerCase()){
      return res.status(400).json({ message: 'Invalid captcha' });
    }

    const conn = await pool.getConnection();
    try{
      const [rows] = await conn.query('SELECT email FROM users WHERE email = ?', [email]);
      if(rows.length) return res.status(400).json({ message: 'Email already registered' });

      const hash = await bcrypt.hash(password, 10);
      await conn.query('INSERT INTO users (email, full_name, phone, shop_name, password_hash) VALUES (?,?,?,?,?)',
        [email, full_name, phone, shop_name, hash]);
      req.session.captcha = null;
      res.json({ message: 'Registered' });
    } finally { conn.release(); }
  }catch(err){
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// login
router.post('/login', async (req, res) => {
  try{
    const { email, password, captcha } = req.body;
    if(!email || !password || !captcha) return res.status(400).json({ message: 'All fields required' });
    if(!req.session.captcha || captcha.toLowerCase() !== req.session.captcha.toLowerCase()){
      return res.status(400).json({ message: 'Invalid captcha' });
    }

    const conn = await pool.getConnection();
    try{
      const [rows] = await conn.query('SELECT email, password_hash, full_name FROM users WHERE email = ?', [email]);
      if(rows.length === 0) return res.status(400).json({ message: 'User not found' });
      const user = rows[0];
      const ok = await bcrypt.compare(password, user.password_hash);
      if(!ok) return res.status(400).json({ message: 'Invalid credentials' });

      const token = jwt.sign({ email: user.email, name: user.full_name }, process.env.JWT_SECRET || 'jwt_secret', { expiresIn: '8h' });
      req.session.captcha = null;
      res.json({ message: 'Login success', token });
    } finally { conn.release(); }
  }catch(err){ console.error(err); res.status(500).json({ message: 'Server error' }); }
});

module.exports = router;
