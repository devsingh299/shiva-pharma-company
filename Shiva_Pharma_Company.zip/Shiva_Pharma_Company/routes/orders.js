const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const pool = require('../db');

// Ensure orders table
async function ensureOrders(){
  const create = `
    CREATE TABLE IF NOT EXISTS orders (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_email VARCHAR(255),
      item_name VARCHAR(255),
      quantity INT,
      address TEXT,
      payment_method VARCHAR(50),
      payment_details TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `;
  const conn = await pool.getConnection();
  try{ await conn.query(create); } finally { conn.release(); }
}
ensureOrders().catch(console.error);

// ✅ Common auth middleware
function verifyToken(req, res, next){
  const authHeader = req.headers.authorization;
  if(!authHeader) return res.status(401).json({ message: 'No token' });
  const token = authHeader.split(' ')[1];
  try{
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'jwt_secret');
    req.user = decoded;
    next();
  }catch(err){
    return res.status(401).json({ message: 'Invalid token' });
  }
}

// ✅ Create order
router.post('/create', verifyToken, async (req, res) => {
  try{
    const { item_name, quantity, address, payment_method, payment_details } = req.body;
    if(!item_name || !quantity || !address || !payment_method)
      return res.status(400).json({ message: 'Missing fields' });

    const conn = await pool.getConnection();
    try{
      await conn.query(
        'INSERT INTO orders (user_email, item_name, quantity, address, payment_method, payment_details) VALUES (?,?,?,?,?,?)',
        [req.user.email, item_name, quantity, address, payment_method, JSON.stringify(payment_details || {})]
      );
      res.json({ message: 'Order placed' });
    } finally { conn.release(); }
  }catch(err){
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// ✅ Get user orders
router.get('/my', verifyToken, async (req, res) => {
  try{
    const email = req.user.email;
    const conn = await pool.getConnection();
    try{
      const [rows] = await conn.query(
        'SELECT * FROM orders WHERE user_email=? ORDER BY created_at DESC',
        [email]
      );
      const orders = rows.map(r => ({
        ...r,
        payment_details: r.payment_details ? JSON.parse(r.payment_details) : null
      }));
      res.json({ orders });
    } finally { conn.release(); }
  }catch(err){
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
