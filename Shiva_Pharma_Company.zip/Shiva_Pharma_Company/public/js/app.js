// app.js - categories, items and order handling

// Sample data (you can later fetch from server)
const CATEGORIES = [
  { id:'digital', title:'Digital Machines', items: [
    { id:'dm1', name:'BP Digital Monitor', desc:'BP monitor - accurate readings' , img:"assets/bpmachine.jpg"},
    { id:'dm2', name:'Glucometer', desc:'Blood sugar monitoring device' , img:"assets/glucometer.jpg"},
    { id:'dm3', name:'Thermometer', desc:'Digital thermometer' , img:"assets/thermometer.jpg"},
    { id:'dm4', name:'Pulse Oximeter', desc:'Measures SpO2 & pulse' , img:"assets/pulseOximeter.jpg"}
  ]},
  { id:'med', title:'Medicines', items: [
    { id:'m1', name:'Paracetamol 500mg', desc:'Pain relief tablet' , img:"assets/PYREMUST-650-TAB.jpg"},
    { id:'m2', name:'Amoxicillin 250mg', desc:'Antibiotic capsule', img:"assets/amoxicillin.jpg"},
    { id:'m3', name:'Vitamin C 500mg', desc:'Supplement' , img:"assets/vc.jpg"},
    { id:'m4', name:'Cough Syrup', desc:'For cough & cold' , img:"assets/cough.jpeg"}
  ]},
  { id:'oper', title:'Operational Instruments', items: [
    { id:'o1', name:'Stethoscope', desc:'Classic stethoscope' , img:"assets/stetho.jpg"},
    { id:'o2', name:'Surgical Scissors', desc:'Stainless steel' , img:"assets/scissor.jpg"},
    { id:'o3', name:'Forceps', desc:'Medical forceps' , img:"assets/foceps.jpeg"},
    { id:'o4', name:'Syringe Kit', desc:'Disposable syringe set' , img:"assets/syring.jpg"}
  ]},
  { id:'safety', title:'Safety Gloves & Hand Sanitizer', items: [
    { id:'s1', name:'Nitrile Gloves (Box)', desc:'Disposable gloves' , img:"assets/nitrile.jpg"},
    { id:'s2', name:'Latex Gloves', desc:'Disposable latex gloves' , img:"assets/latex.jpg"},
    { id:'s3', name:'Hand Sanitizer 500ml', desc:'Alcohol based sanitizer' , img:"assets/handSanitizer.jpeg"},
    { id:'s4', name:'Sanitizer Spray', desc:'Surface sanitizer' , img:"assets/spray.jpeg"}
  ]},
  { id:'inj', title:'Injections', items: [
    { id:'i1', name:'Insulin Injection', desc:'For diabetes (subject to prescription)' , img:"assets/insulin.jpeg"},
    { id:'i2', name:'Vitamin B12 Injection', desc:'Supplementary injection' , img:"assets/v12.jpeg"},
    { id:'i3', name:'Antibiotic Injection', desc:'IM Injection - dosage varies' , img:"assets/anti.jpg"},
    { id:'i4', name:'Pain Relief Injection', desc:'Analgesic injection' , img:"assets/pain.jpg"}
  ]}
];

// ✅ Render all categories
function renderCategories(){
  const catEl = document.getElementById('categories');
  catEl.innerHTML = '';
  CATEGORIES.forEach(cat=>{
    const d = document.createElement('div');
    d.className = 'card';
    d.innerHTML = `<h4>${cat.title}</h4><p class="muted">Click to view items</p>`;
    d.addEventListener('click', ()=> showCategory(cat.id));
    catEl.appendChild(d);
  });
}

// ✅ Show category items with images
function showCategory(catId){
  const cat = CATEGORIES.find(c => c.id === catId);
  document.getElementById('catTitle').innerText = cat ? cat.title : '';
  const itemsEl = document.getElementById('items');
  itemsEl.innerHTML = '';

  (cat?.items || []).forEach(it => {
    const card = document.createElement('div');
    card.className = 'card';

    const img = document.createElement('img');
    img.src = it.img || "assets/no-image.png";
    img.style.width = "100%";
    img.style.height = "300px";
    img.style.objectFit = "cover";
    img.style.borderRadius = "8px";

    const h = document.createElement('h4');
    h.innerText = it.name;

    const p = document.createElement('p');
    p.innerText = it.desc;

    const btn = document.createElement('button');
    btn.className = "small";
    btn.innerText = "View";
    btn.addEventListener("click", () => openItem(it));

    card.appendChild(img);
    card.appendChild(h);
    card.appendChild(p);
    card.appendChild(btn);

    itemsEl.appendChild(card);
  });
}

// ✅ Open modal for item
function openItem(item){
  document.getElementById('itemName').innerText = item.name;
  document.getElementById('itemDesc').innerText = item.desc;
  document.getElementById('orderQty').value = 1;
  document.getElementById('orderAddress').value = '';
  document.getElementById('paymentMethod').value = 'COD';
  document.getElementById('upiId').value = '';
  document.getElementById('paymentDetailsArea').classList.add('hidden');
  document.getElementById('orderModal').classList.remove('hidden');

  const placeBtn = document.getElementById('placeOrder');
  placeBtn.onclick = ()=> placeOrder(item.name);
}

// ✅ Close modal
document.getElementById('closeModal')?.addEventListener('click', ()=> {
  document.getElementById('orderModal').classList.add('hidden');
});

// ✅ Payment method toggle
document.getElementById('paymentMethod')?.addEventListener('change', (e)=>{
  if(e.target.value === 'UPI') document.getElementById('paymentDetailsArea').classList.remove('hidden');
  else document.getElementById('paymentDetailsArea').classList.add('hidden');
});

// ✅ Place order - calls backend
async function placeOrder(itemName){
  const qty = parseInt(document.getElementById('orderQty').value) || 1;
  const address = document.getElementById('orderAddress').value.trim();
  const payment_method = document.getElementById('paymentMethod').value;
  const payment_details = payment_method === 'UPI' ? { upi: document.getElementById('upiId').value.trim() } : {};

  if(!address) return alert('Address required');

  const token = localStorage.getItem('token');
  if(!token) { alert('Not logged in'); window.location.href='index.html'; return; }

  try {
    const res = await fetch('/api/orders/create', {
      method:'POST',
      headers: {
        'Content-Type':'application/json',
        'Authorization':'Bearer ' + token
      },
      body: JSON.stringify({ item_name: itemName, quantity: qty, address, payment_method, payment_details })
    });

    if (!res.ok) throw new Error('Failed to place order');
    const data = await res.json();

    alert(data.message || 'Order response');
    if(data.message === 'Order placed'){
      document.getElementById('orderModal').classList.add('hidden');
    }

  } catch (err) {
    console.error(err);
    alert('Server error while placing order');
  }
}

// ✅ Logout
document.getElementById('logoutBtn')?.addEventListener('click', ()=>{
  localStorage.removeItem('token');
  window.location.href = 'index.html';
});

// ✅ Go to My Orders
document.getElementById('myOrderbtn')?.addEventListener('click', ()=>{
  window.location.href = 'myorders.html';
});

// ✅ Initialize
renderCategories();
