// auth.js - login and register handling

// Login button on index.html
document.addEventListener('DOMContentLoaded', ()=>{
  const btnLogin = document.getElementById('btnLogin');
  if(btnLogin){
    btnLogin.addEventListener('click', loginUser);
  }

  const btnSubmit = document.getElementById('btnSubmit');
  if(btnSubmit) btnSubmit.addEventListener('click', registerUser);

  const btnClear = document.getElementById('btnClear');
  if(btnClear) btnClear.addEventListener('click', clearForm);

  // If dashboard page, set vendor name
  const token = localStorage.getItem('token');
  if(token && document.getElementById('vendorName')){
    try{
      const payload = JSON.parse(atob(token.split('.')[1]));
      document.getElementById('vendorName').innerText = payload.name;
    } catch(e){}
  }
});

// helper to reload captcha images
function reloadCaptchaFor(id){
  document.getElementById(id).src = '/api/auth/captcha?' + Date.now();
}

// LOGIN
async function loginUser(){
  const email = document.getElementById('loginEmail')?.value?.trim();
  const pass = document.getElementById('loginPassword')?.value?.trim();
  const captcha = document.getElementById('loginCaptcha')?.value?.trim();

  if(!email || !pass || !captcha) return alert('⚠ कृपया सभी फ़ील्ड भरें।');

  try{
    const res = await fetch('/api/auth/login', {
      method:'POST',
      headers: {'Content-Type':'application/json'},
      credentials: 'include',
      body: JSON.stringify({ email, password: pass, captcha })
    });
    const data = await res.json();
    alert(data.message || 'Response received');
    if(data.token){
      localStorage.setItem('token', data.token);
      globalThis.location.href = 'dashboard.html';
    } else {
      // reload captcha on failure
      reloadCaptchaFor('captchaImg');
    }
  }catch(err){
    alert('Server error');
    reloadCaptchaFor('captchaImg');
  }
}

// REGISTER
async function registerUser(){
  const full_name = document.getElementById('fullName')?.value?.trim();
  const email = document.getElementById('email')?.value?.trim();
  const phone = document.getElementById('phone')?.value?.trim();
  const shop_name = document.getElementById('shop')?.value?.trim();
  const password = document.getElementById('password')?.value;
  const password2 = document.getElementById('password2')?.value;
  const captcha = document.getElementById('captchaReg')?.value?.trim();

  // client-side validation & alerts
  if(!full_name) return alert('Full name required');
  if(!email) return alert('Email required');
  if(!phone) return alert('Mobile number required');
  if(!shop_name) return alert('Shop name required');
  if(!password) return alert('Password required');
  if(password !== password2) return alert('Password and Re-enter password must match');
  if(!captcha) return alert('Enter captcha');

  try{
    const res = await fetch('/api/auth/register', {
      method:'POST',
      headers: {'Content-Type':'application/json'},
      credentials: 'include',
      body: JSON.stringify({ full_name, email, phone, shop_name, password, captcha })
    });
    const data = await res.json();
    alert(data.message || 'Response received');
    if(data.message === 'Registered'){
      window.location.href = 'index.html';
    } else {
      reloadCaptchaFor('captchaImgReg');
    }
  }catch(err){
    alert('Server error');
    reloadCaptchaFor('captchaImgReg');
  }
}

function clearForm(){
  ['fullName','email','phone','shop','password','password2','captchaReg'].forEach(id=>{
    const el = document.getElementById(id);
    if(el) el.value = '';
  });
}
